<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <div class="wrapper">
        
        <a href="order.php"><button class="select">Забронировать</button></a>

        <header class="header">
            <div class="container">
                <div class="header__body">
                    <div class="header__logo">
                        <object data="svg/logo.svg"></object>
                    </div>

                    <nav class="header__navbar">
                        <ul class="header__list">
                            <li><a href="#main__menu" class="header__link">Главная</a></li>
                            <li><a href="#hostel__num" class="header__link">Наши номера</a></li>
                            <li><a href="#hostel__photo" class="header__link">Фото</a></li>
                            <li><a href="#otzyv__photo" class="header__link">Отзывы</a></li>
                            <li><a href="#hostel__contact" class="header__link">Контакты</a></li>
                            <li><a href="" class="header__link">Правила</a></li>
                            <li><a href="" class="header__link">Наши гости</a></li>
                            <li><a href="order.php" class="header__link">Забронировать</a></li>
                        </ul>
                    </nav>

                    <div class="header__search">
                        <input type="search" class="search" placeholder="Поиск">
                    </div>
                </div>
            </div>
           
        </header>

        <main class="content">
            <section class="main__menu" id="main__menu">
                <div class="container">
                    <div class="menu__body">
                        <h1 class="menu__title">ЭКО-ХОСТЕЛ</h1>
                        <p class="menu__slogan">Продуманный комфорт. Отдых в спокойствии. Уют. Чистота. Экологичность</p>
                        <p class="menu__tel">+7 (909) 543 16 23</p>
                    </div>
                </div>
            </section>

            <section class="advent" id="hostel__num">
                <div class="container">
                    <div class="advent__body">
                        <div class="advent__content advent__content1">
                            <object data="svg/adv/hour.svg"></object>
                            <h4>Мы работаем 24/7</h4>
                            <p>Мы рады Вас видеть в нашем уютном и комфортабельном хостеле в
                                любое время дня и любой день недели</p>
                        </div>
                        <div class="advent__content advent__content2">
                            <object data="svg/adv/center.svg"></object>
                            <h4>В самом центре</h4>
                            <p>За 5-10 минут пешком можно дойти до ГУМа, ЦУМа, набережной и других популярных мест
                            </p>
                        </div>
                        <div class="advent__content advent__content3">
                            <object data="svg/adv/plus.svg"></object>
                            <h4>Все, что нужно</h4>
                            <p>К Вашим услугам: постельное белье с полотенцем, пользование общей кухней, стиральной машиной, утюгом, феном, компьютером, Wi-Fi</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="hostel__num">
                <div class="container">
                    <h2 class="num__title">Наши номера</h2>
                    <div class="hostel__num1">
                        <div class="num__body">
                           <div class="num__content1">
                               <h4>Комната для компании</h4>
                               <p>Комната для четырех человек. Две двухуровневые кровати. Эту комнату мы называем еще «семейной». Она может сдаваться и по местам (при отсутствии мест в других комнатах). В комнате есть рабочий стол, зеркало, диванчик и телевизор.</p>
                           </div>
                        </div>
                    </div>

                    <div class="hostel__num2">
                        <div class="num__body">
                           <div class="num__content2">
                               <h4>Комната повышенной комфортности</h4>
                               <p>Комната для одного или двух человек. Двуспальная кровать.
                                В комнате есть холодильник, микроволновка, чайник, телевизор.
                                Комната укомплектована раковиной.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="hostel__photo" id="hostel__photo">
                <div class="container">
                    <div class="photo__body">
                        <h2 class="photo__title">Наш отель</h2>
                        <div class="photo__slider">
                            <div class="photo__slides">
                                <input type="radio" name="r" id="r1" checked>
                                <input type="radio" name="r" id="r2">
                                <input type="radio" name="r" id="r3">
                                <input type="radio" name="r" id="r4">
                                <input type="radio" name="r" id="r5">

                                <div class="slide slide1 s1">
                                    <img src="img/hostel__photo/1.jpg" alt="Error">
                                </div>
                                <div class="slide slide2">
                                    <img src="img/hostel__photo/2.jpg" alt="Error">
                                </div>
                                <div class="slide slide3">
                                    <img src="img/hostel__photo/3.jpg" alt="Error">
                                </div>
                                <div class="slide slide4">
                                    <img src="img/hostel__photo/4.jpg" alt="Error">
                                </div>
                                <div class="slide slide5">
                                    <img src="img/hostel__photo/5.jpg" alt="Error">
                                </div>
                            </div>

                            <div class="information">
                                <label for="r1" class="rad"></label>
                                <label for="r2" class="rad"></label>
                                <label for="r3" class="rad"></label>
                                <label for="r4" class="rad"></label>
                                <label for="r5" class="rad"></label>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </section>

            <div class="hostel__contact" id="hostel__contact">
                <div class="container">
                    <h2 class="contact__title">Наши контакты</h2>
                    <div class="contact__body">
                        
                        <div class="contact__photo">
                            <img src="img/contact/1.jpg" alt="Error">
                        </div>
                        <div class="contact__information">
                            <p class="contact__tel"><strong>Телефон:</strong>+7 (909) 543 16 23</p>
                            <p class="contact__email"><strong>Email:</strong>hostl@mail.ru</p>
                            <p class="vk"><strong>ВКонтакте</strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <section class="otzyv__photo" id="otzyv__photo">
                <div class="container">
                    <div class="otz__body">
                        <h2 class="photo__title">Отзывы</h2>
                        <div class="otz__slider">
                            <div class="otz__slides">
                                <input type="radio" name="rr" id="or1" checked>
                                <input type="radio" name="rr" id="or2">
                                <input type="radio" name="rr" id="or3">
                                <input type="radio" name="rr" id="or4">
                                <input type="radio" name="rr" id="or5">

                                <div class="otz__slide slide1 a1">
                                    
                                    <div class="logo__otz"></div>
                                    <h4>Артём Кужлев</h4>
                                    <p>Прекрасно провёл время. Аккуратные, чистые номера и прекрасные хозяева!</p>
                                </div>
                                <div class="otz__slide slide2">
                                    <div class="logo__otz"></div>
                                    <h4>Лана Т.</h4>
                                    <p>Здравствуйте,Фортуна!Останавливались на ночлег по пути домой с 2 мопсами. Приветливый администратор,отличные условия проживания.Если снова будем проездом в Симферополе,то остановимся именно в этом хостеле. Желаем процветания!!! Алексей,Светлана+ питомцы (Москва)</p>
                                </div>
                                <div class="otz__slide slide3">
                                    <div class="logo__otz"></div>
                                    <h4>Станислав Г.</h4>
                                    <p>Хороший чистый хостел. Все есть, все на уровне!</p>
                                </div>
                                <div class="otz__slide slide4">
                                    <div class="logo__otz"></div>
                                    <h4>Марина</h4>
                                    <p>Плюсы: Всё прошло отлично. Очень рекомендую эту гостиницу. Расположение-тихое, место в 10 мин от вокзала. На территории есть частная парковка. Номера большие с комфортабельной кроватью, ортопедическим матрацом. Завтрак вполне приличный. Хорошее соотношение цены и качества</p>
                                </div>
                                <div class="otz__slide slide5">
                                    <div class="logo__otz"></div>
                                    <h4>Юлия</h4>
                                    <p>Плюсы: Хороший хостел! Чисто , спокойно . Останавливалась на одну ночь . Встретили с поздним заездом без проблем. Спасибо за все</p>
                                </div>
                            </div>

                            <div class="information">
                                <label for="or1" class="otz__rad"></label>
                                <label for="or2" class="otz__rad"></label>
                                <label for="or3" class="otz__rad"></label>
                                <label for="or4" class="otz__rad"></label>
                                <label for="or5" class="otz__rad"></label>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </section>
        </main>

        <footer class="footer">
            <div class="container">
                <div class="footer__body">
                    <h2>ЭКО ОТЕЛЬ</h2>
                    <a href="order.php"><button class="select">Забронировать</button></a>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>