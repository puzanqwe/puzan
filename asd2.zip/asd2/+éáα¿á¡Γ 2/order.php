<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <div class="wrapper">
        
        <a href="order.php"><button class="select">Забронировать</button></a>

        <header class="header">
            <div class="container">
                <div class="header__body">
                    <div class="header__logo">
                        <object data="svg/logo.svg"></object>
                    </div>

                    <nav class="header__navbar">
                        <ul class="header__list">
                            <li><a href="#main__menu" class="header__link">Главная</a></li>
                            <li><a href="#hostel__num" class="header__link">Наши номера</a></li>
                            <li><a href="#hostel__photo" class="header__link">Фото</a></li>
                            <li><a href="#otzyv__photo" class="header__link">Отзывы</a></li>
                            <li><a href="#hostel__contact" class="header__link">Контакты</a></li>
                            <li><a href="" class="header__link">Правила</a></li>
                            <li><a href="" class="header__link">Наши гости</a></li>
                            <li><a href="order.php" class="header__link">Забронировать</a></li>
                        </ul>
                    </nav>

                    <div class="header__search">
                        <input type="search" class="search" placeholder="Поиск">
                    </div>
                </div>
            </div>
           
        </header>


        <form class="feedback-form" action="./order_config.php" method="post">
            <div class="feedback-form-group">
               <label for="fullname">Представьтесь:</label>
               <input name="fullname" type="text"  id="fullname" placeholder="Как мы можем к вам обращаться?">
            </div>
            <div class="feedback-form-group">
               <label for="phone">Номер телефона:</label>
               <input name="phone"  type="text"  id="phone" placeholder="+7 (XXX) XXX-XX-XX">
               
            </div>

            <div class="feedback-form-group size">
               <label for="number">Размещение в номере</label>
               <input name="number" type="number"  id="number" placeholder="Количество кроватей" min="1" max="4">
            </div>

            <div class="feedback-form-group size">
               <label for="date">Дата заезда</label>
               <input name="date1" type="date" id="date" placeholder="" min="1" max="4">
            </div>
            <div class="feedback-form-group size">
               <label for="date">Дата выезда</label>
               <input name="date2" type="date" id="date" placeholder="" min="1" max="4">
            </div>

            <div class="feedback-form-group">
               <label class="labtext" for="message">Доп. комментарий:</label>
               <textarea name="message" rows="10" cols="50"  id="message" placeholder="Сообщите нам всё, что считаете нужным"></textarea>
            </div>
            <div class="checkbox-area">
            
             

            </div>
            <input type="submit" class="btn" value="Отправить заказ">
            </form>
</body>