<?php

    session_start();
    require_once 'config.php';

    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $number = $_POST['number'];
    $date1 = $_POST['date1'];
    $date2 = $_POST['date2'];
    $message = $_POST['message'];
    

    mysqli_query($connect, "INSERT INTO `v2` (`id`, `fullname`, `phone`, `number`, `date1`, `date2`, `message`) VALUES (NULL, '$fullname', '$phone', '$number', '$date1', '$date2', '$message')");
    header('Location: ./index.php');
    
    
?>
