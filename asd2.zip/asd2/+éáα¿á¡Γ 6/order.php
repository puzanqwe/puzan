<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header>
        <div class="header">
            <div class="logo">
                <img src="img/svg-editor-image.svg" alt="" class="logo_svg">
            </div>
            <div class="header_links">
                <a href="second_page.html" class="header_link link">Наши работы</a>
                <a href="order.php" class="header_link1 link">Заказать 3D-Продукт</a>
                <a href="first_page.html" class="header_link1 link">О нас</a>
            </div>
        </div>
    </header>



    <form class="feedback-form" action="./order_config.php" method="post">
            <div class="feedback-form-group">
               <label for="fullname">Представьтесь:</label>
               <input name="fullname" type="text"  id="fullname" placeholder="Как мы можем к вам обращаться?">
            </div>
            <div class="feedback-form-group">
               <label for="phone">Номер телефона:</label>
               <input name="phone"  type="text"  id="phone" placeholder="+7 (XXX) XXX-XX-XX">
               
            </div>
            <div class="feedback-form-group">
               <label for="mail">E-mail:</label>
               <input name="mail" type="text"  id="mail" placeholder="Ваша электронная почта">
            </div>

            
            <div class="feedback-form-group">
               <label class="labtext" for="message">Описание вашего заказа:</label>
               <textarea name="message" rows="10" cols="50"  id="message" placeholder="Мы свяжемся с вами"></textarea>
            </div>

              
          
            <input type="submit" class="btn" value="Отправить заказ">
            </form>

</body>