<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header>
        <div class="header">
            <div class="logo">
                <img src="img/svg-editor-image.svg" alt="" class="logo_svg">
            </div>
            <div class="header_links">
                <a href="second_page.html" class="header_link link">Наши работы</a>
                <a href="order.php" class="header_link1 link">Заказать 3D-Продукт</a>
                <a href="first_page.html" class="header_link1 link">О нас</a>
            </div>
        </div>
    </header>
    <div class="main_content">
        <div class="main_info">
            <p class="main_title">Simple 3D Print [3D печать и моделирование]</p>
        </div>
        <div class="information">
            <div class="main_logo">
                <img src="img/print.png" alt="" class="logo_main">
            </div>
            <div class="about">
                <p>Сайт посвящен разработке и печати 3D моделей<br>Pet-G, PLA, ABS пластиками в кратчайшие
                    сроки,<br>например:
                    переходники, игрушки сувениры,<br>шестеренки, крепежи, макеты, запчасти и зип,<br>корпуса, элементы
                    декора и
                    любые другие<br>вещи, которые ВЫ захотите. 
                    Печать осуществляется по вашим моделям<br>(STL,OBJ), либо по детали, эскизу, чертежам.<br>Так же
                    можем
                    сделать дизайн по вашим<br>картинкам или рисункам. </p>
            </div>
        </div>
    </div>
    <div class="examples">
        <p class="d-examples">Примеры 3D-моделей</p>
        <div class="pictures_first">
            <img src="img/putin.png" alt="" class="putin img">
            <img src="img/something.png" alt="" class="something img">
            <img src="img/house.png" alt="">
        </div>
        <div class="pictures_second">
            <img src="img/circle.png" alt="" class="circle">
            <img src="img/bird.png" alt="" class="bird">
            <img src="img/hearts.png" alt="" class="">
        </div>
    </div>
    <footer class="footer">
        <div class="footer_links">
            <a href="second_page.html" class="footer_link link">Модели</a>
            <a href="order.php" class="footer_link1 link">Заказать</a>
            <a href="first_page.html" class="footer_link2 link">О нас</a>
            <a href="#" class="social"><img src="img/Vector.png" alt="" class="vector vk"></a>
            <a href="#" class="social"><img src="img/Vector2.png" alt="" class="vector facebook"></a>
            <a href="#" class="social"><img src="img/Vector3.png" alt="" class="youtube"></a>
        </div>
    </footer>
</body>

</html>