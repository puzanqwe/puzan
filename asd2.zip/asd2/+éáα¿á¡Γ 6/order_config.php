<?php

    session_start();
    require_once 'config.php';

    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $mail = $_POST['mail'];
    $message = $_POST['message'];

    mysqli_query($connect, "INSERT INTO `v6` (`id`, `fullname`, `phone`, `mail`, `message`) VALUES (NULL, '$fullname', '$phone', '$mail', '$message')");
    header('Location: ./first_page.php');
    
    
?>
