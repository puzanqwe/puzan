<?php

    session_start();
    require_once 'config.php';

    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $mail = $_POST['mail'];
    $message = $_POST['message'];

    mysqli_query($connect, "INSERT INTO `v5` (`id`, `name`, `surname`, `mail`, `message`) VALUES (NULL, '$name', '$surname', '$mail', '$message')");
    header('Location: ./index.php');

?>