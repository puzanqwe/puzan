<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main_page.css">
    <title>Document</title>
</head>

<body>
    <header>
        <div class="header_menu">
            <img src="img/moto_moto_logo-02.svg" alt="" class="logo">
            <div class="header_links">
                <a href="for_client.html" class="link1">Покупателю</a>
                <a href="about_us.html" class="link2">О нас</a>
                <a href="form.php" class="link3">Обратная связь</a>
            </div>
        </div>
    </header>

    <div class="contact">
	<div class="container">
		<h3>Свяжитесь с нами</h3>
		<p>Хотите предложить новый товар, идею или ищете работу - пишите!</p>
		<form id="orders" action="form_config.php" method="post">
			 <input name="name" type="text"  placeholder="Имя" >
			 <input name="surname" type="text"  placeholder="Фамилия">			 
			 <input name="mail" class="user"  type="text" placeholder="E-mail"><br>
			 <textarea name="message" type="text" placeholder="Сообщение" ></textarea>
			 <input type="submit" name="submit" value="Отправить">
		</form>
	</div>
</div>

</body>