<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main_page.css">
    <title>Document</title>
</head>

<body>
    <header>
        <div class="header_menu">
            <img src="img/moto_moto_logo-02.svg" alt="" class="logo">
            <div class="header_links">
                <a href="for_client.html" class="link1">Покупателю</a>
                <a href="about_us.html" class="link2">О нас</a>
                <a href="form.php" class="link3">Обратная связь</a>
            </div>
        </div>
    </header>
    <div class="main_information">
        <p class="main_header">Мотоциклы</p>
        <div class="main_links">
            <a href="classic_moto.html" class="main_link">Классические мотоциклы</a>
            <a href="sport_moto.html" class="main_link">Спортивные мотоциклы</a>
            <a href="choppers_moto.html" class="main_link">Чопперы</a>
            <a href="turrers_moto.html" class="main_link">Туреры</a>
            <a href="skuters_moto.html" class="main_link1">Скутеры</a>
        </div>
        <div class="main_info">
            <div class="about_moto">
                <div class="test">
                    <div>
                        <p class="moto">Классические мотоциклы</p>
                        <p class="info_moto">Классический мотоцикл это проверенный <br>временем дизайн и компоновка,
                            прямая
                            посадка <br>и неприхотливость в обслуживании, надежность <br>и удобство в эксплуатации.
                            Внешне
                            он
                            может <br>быть
                            немного похож как на чоппер, но не с <br>такой вальяжной посадкой водителя и тоннами
                            <br>хрома,
                            так
                            и на
                            спортбайк, только с более <br>спокойными характеристиками двигателя и <br>длинными
                            тяговитыми
                            передачами.</p>
                    </div>
                    <img src="img/try.png" alt="" class="moto_img">
                </div>
                <div class="examples">
                    <div class="moto_example1">
                        <a href="jawa_info.php" class="check"> 
                            <p class="header_moto">JAWA 350 Premier</p>
                            <img src="img/s1200.png" alt="" class="JAWA">
                            <p class="price">от 290 000 ₽</p>
                            <p class="characteristic">397 куб.см, 23 л.с, 30.6 Н*м, 160 кг,<br>
                                кикстартер и раздельная система смазки</p>
                        </a>
                    </div>
                    <div class="moto_example2">
                        <a href="guzzi_info.php" class="check">
                            <p class="header_moto">Moto Guzzi V7 III ANNIVERSARIO</p>
                            <img src="img/guzzi.jpg" alt="" class="Guzzi">
                            <p class="price">от 859 000 ₽</p>
                            <p class="characteristic">744 куб.см, 52 л.с, 60 Н*м<br>
                                4900 об/мин,189 кг</p>
                        </a>
                    </div>
                </div>
                <div class="button">
                    <a href="classic_moto.html"><input type="button" name="submit" id="" value="Остальные модели" class="sent"></a>
                </div>
            </div>
            <div class="about_moto">
                <div class="test">
                    <div>
                        <p class="moto">Спортивные мотоциклы</p>
                        <p class="info_moto">Мотоциклы, которые дают ощущение свободы <br>своим обладателям, находясь на
                            витых дорогах <br>города или гладком асфальте специальных <br>треков. Благодаря совершенным
                            тормозным <br>системам, они способны менее чем за 3 секунды <br>молниеносно разогнаться с
                            места до
                            100 км/ч, <br>увеличить скорость в разы и с легкостью <br>остановиться.</p>
                    </div>
                    <img src="img/sport 1.png" alt="" class="moto_img">
                </div>
                <div class="examples">
                    <div class="sport_moto">
                        <a href="r1_moto.php" class="check">
                            <p class="header_moto">YZF-R1</p>
                            <img src="img/moto1.jpg" alt="" class="sportmoto">
                            <p class="price">от 290 000 ₽</p>
                            <p class="characteristic">397 куб.см, 23 л.с, 30.6 Н*м, 160 кг,<br>
                                кикстартер и раздельная система смазки</p>
                        </a>
                    </div>
                    <div class="moto_example2">
                        <a href="r3_moto.php" class="check">
                            <p class="header_moto">YZF-R3</p>
                            <img src="img/mtoo31.jpg" alt="" class="sportmoto2">
                            <p class="price">от 429 000 ₽</p>
                            <p class="characteristic">321 куб. см, 29 Н*м 10 750 об/мин, 201 кг,<br>
                                3,8 л/100 км, транзисторная система<br> зажигания TCI</p>
                        </a>
                    </div>
                </div>
                <div class="button">
                    <a href="sport_moto.html"><input type="button" name="submit" id="" value="Остальные модели" class="sent"></a>
                </div>
            </div>
            <div class="about_moto">
                <div class="test">
                    <div>
                        <p class="moto">Чопперы</p>
                        <p class="info_moto">Мощные тяжёлые мотоциклы для неспешных<br> поездок по городу. Пластиковых
                            обтекателей ни<br> имеют. Обеспечивают удобную прямую и<br> низкую посадку «ногами вперёд»
                            за счёт<br>
                            вынесенных вперёд подножек. Отличаются<br> низкооборотистыми двигателями. Ценятся<br>
                            владельцами за
                            возможность легко и вальяжно<br> кататься, наблюдая окрестности и показывая<br> себя.</p>
                    </div>
                    <img src="img/harley1.png" alt="" class="moto_img">
                </div>
                <div class="examples">
                    <div class="moto_example1">
                        <a href="forty_moto.php" class="check">
                            <p class="header_moto">FORTY-EIGHT</p>
                            <img src="img/chopper.PNG" alt="" class="JAWA">
                            <p class="price">от 1 499 000 ₽</p>
                            <p class="characteristic">1 202 куб. см, 96 Н*м 11 500 об/мин, 252кг,<br> Электронная
                                система
                                последовательного<br> впрыска топлива</p>
                        </a>
                    </div>
                    <div class="moto_example2">
                        <a href="superflow_moto.php" class="check">
                            <p class="header_moto">SUPERFLOW 1200T</p>
                            <img src="img/superflow.PNG" alt="" class="Guzzi">
                            <p class="price">от 429 000 ₽</p>
                            <p class="characteristic">321 куб. см, 96 Н*м 10 750 об/мин, 263 кг,<br>
                                17 л, электронная система<br> последовательного впрыска топлива</p>
                        </a>
                    </div>
                </div>
                <div class="button">
                    <a href="choppers_moto.html"><input type="button" name="submit" id="" value="Остальные модели" class="sent"></a>
                </div>
            </div>
            <div class="about_moto">
                <div class="test">
                    <div>
                        <p class="moto">Туреры</p>
                        <p class="info_moto">Мотоциклы, предназначенные для путешествий<br> на большие расстояния.
                            Отличаются<br> комфортной посадкой, топливными баками<br> большой ёмкости,
                            низкооборотистыми<br>
                            двигателями, крупными размерами.<br> Управляемость приносится в жертву комфорту.<br>
                            Туристические
                            мотоциклы имеют большое<br> количество дополнительного оборудования:<br> кондиционеры,
                            магнитолы,
                            подушки<br> безопасности.</p>
                    </div>
                    <img src="img/turers1.png" alt="" class="moto_img">
                </div>
                <div class="examples">
                    <div class="moto_example1">
                        <a href="limited_moto.php" class="check">
                            <p class="header_moto">ULTRA LIMITED</p>
                            <img src="img/turer.PNG" alt="" class="JAWA">
                            <p class="price">от 2 563 000 ₽</p>
                            <p class="characteristic">1 202 куб. см, 164 Н*м, 399кг, электронная<br> система
                                последовательного впрыска<br> топлива</p>
                        </a>
                    </div>
                    <div class="moto_example2">
                        <a href="glide_moto.php" class="check">
                            <p class="header_moto">ROAD GLIDE SPECIAL</p>
                            <img src="img/turer2.PNG" alt="" class="Guzzi">
                            <p class="price">от 2 434 000 ₽</p>
                            <p class="characteristic">1 868 куб. см, 163 Н*м, 371 кг, 22.7 л,<br> электронная система
                                последовательного<br> впрыска топлива</p>
                        </a>
                    </div>
                </div>
                <div class="button">
                    <a href="turrers_moto.html"><input type="button" name="submit" id="" value="Остальные модели" class="sent"></a>
                </div>
            </div>
            <div class="about_moto">
                <div class="test">
                    <div>
                        <p class="moto">Скутеры</p>
                        <p class="info_moto">Настоящее спасение для того, кто нуждается в<br> транспорте, но не любит
                            стоять
                            в пробках. Это<br> техническое средство имеет нечто общее с<br> мотоциклом, но отличается
                            меньшей<br>
                            мощностью, размерами и весом.</p>
                    </div>
                    <img src="img/123.png" alt="" class="moto_img">
                </div>
                <div class="examples">
                    <div class="moto_example1">
                        <a href="tmax_moto.php" class="check">
                            <p class="header_moto">TMAX DX</p>
                            <img src="img/skuter.PNG" alt="" class="JAWA">
                            <p class="price">от 936 000 ₽</p>
                            <p class="characteristic">562 куб. см, 55 Н*м 5 250 об/мин, 220 кг,<br> транзисторная
                                система
                                зажигания TCI</p>
                        </a>
                    </div>
                    <div class="moto_example2">
                        <a href="nmax_moto.php" class="check">
                            <p class="header_moto">NMAX 150</p>
                            <img src="img/skuter2.PNG" alt="" class="Guzzi">
                            <p class="price">от 268 000 ₽</p>
                            <p class="characteristic">155 куб. см, 14 Н*м 6 000 об/мин, 127 кг,<br> 6.6 л, транзисторная
                                система зажигания TCI</p>
                        </a>
                    </div>
                </div>
                <div class="button">
                    <a href="skuters_moto.html"><input type="button" name="submit" id="" value="Остальные модели" class="sent"></a>
                </div>
            </div>
        </div>
    </div>
    </div>
    <footer>
        <div class="footer_links">
            <div class="first_part">
                <p class="header">Мотоциклы</p><br>
                <a href="classic_moto.html" class="footer_link">Классические мотоциклы</a>
                <a href="sport_moto.html" class="footer_link">Спортивные мотоциклы</a><br>
                <div class="flink">
                <a href="choppers_moto.html" class="flink">Чопперы</a>
                <a href="turrers_moto.html" class="flink">Туреры</a>
                <a href="skuters_moto.html" class="flink">Скутеры</a>
            </div>
            </div>
            <div class="second_part">
                <div class="social">
                    <div class="hi">
                <a href="#" class="vektor"><img src="img/iconmonstr-vk-5.svg" alt=""></a>
                <a href="#" class="vektor"><img src="img/iconmonstr-facebook-5.svg" alt=""></a>
                <a href="#"><img src="img/iconmonstr-youtube-5.svg" alt=""></a>
                </div>
                </div>
                <div class="footer_button">
                    <a href="form.php"><input type="button" name="submit" id="" value="Обратная связь" class="button_footer"></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>