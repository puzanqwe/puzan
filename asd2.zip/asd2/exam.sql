-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 25 2025 г., 19:33
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `exam`
--

-- --------------------------------------------------------

--
-- Структура таблицы `v1`
--

CREATE TABLE `v1` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v1`
--

INSERT INTO `v1` (`id`, `name`, `phone`) VALUES
(2, 'Дарья', '89524066741'),
(3, 'ждуми', '89524066741');

-- --------------------------------------------------------

--
-- Структура таблицы `v2`
--

CREATE TABLE `v2` (
  `id` int NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `number` int NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v2`
--

INSERT INTO `v2` (`id`, `fullname`, `phone`, `number`, `date1`, `date2`, `message`) VALUES
(2, 'Голосова Дарья Витальевна', '+79524066741', 1, '2025-02-28', '2025-03-07', 'fsdbdsasf'),
(3, 'Голосова Дарья Витальевна', '+79524066741', 1, '2025-02-27', '2025-02-27', 'панвекапгршощлзождролпрап');

-- --------------------------------------------------------

--
-- Структура таблицы `v5`
--

CREATE TABLE `v5` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mail` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v5`
--

INSERT INTO `v5` (`id`, `name`, `surname`, `mail`, `message`) VALUES
(4, 'Дарья', 'Голосова', 'ruebennett@mail.ru', 'dsfgfbfnbv');

-- --------------------------------------------------------

--
-- Структура таблицы `v6`
--

CREATE TABLE `v6` (
  `id` int NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `message` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v6`
--

INSERT INTO `v6` (`id`, `fullname`, `phone`, `mail`, `message`) VALUES
(1, 'Голосова Дарья Витальевна', '+79524066741', 'ruebennett@mail.ru', 'sfzgdcmvh');

-- --------------------------------------------------------

--
-- Структура таблицы `v7`
--

CREATE TABLE `v7` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v7`
--

INSERT INTO `v7` (`id`, `name`, `login`, `mail`, `pass`) VALUES
(1, 'Голосова Дарья Витальевна', 'qqq', 'ruebennett@mail.ru', 'b2ca678b4c936f905fb82f2733f5297f');

-- --------------------------------------------------------

--
-- Структура таблицы `v8`
--

CREATE TABLE `v8` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v8`
--

INSERT INTO `v8` (`id`, `name`, `surname`, `mail`, `message`) VALUES
(1, 'Дарья', 'Голосова', 'ruebennett@mail.ru', 'dafsdfghhj');

-- --------------------------------------------------------

--
-- Структура таблицы `v9`
--

CREATE TABLE `v9` (
  `id` int NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `phonetwo` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `size` int NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v9`
--

INSERT INTO `v9` (`id`, `fullname`, `phone`, `phonetwo`, `mail`, `size`, `message`) VALUES
(1, 'Голосова Дарья Витальевна', '+79524066741', '+79524066741', 'ruebennett@mail.ru', 1234, 'sfdgfhfjgkhgfhdgsf');

-- --------------------------------------------------------

--
-- Структура таблицы `v10`
--

CREATE TABLE `v10` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `v10`
--

INSERT INTO `v10` (`id`, `name`, `mail`, `phone`, `country`) VALUES
(1, 'Голосова Дарья Витальевна', 'ruebennett@mail.ru', '9524066741', 'Portugal');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `v1`
--
ALTER TABLE `v1`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v2`
--
ALTER TABLE `v2`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v5`
--
ALTER TABLE `v5`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v6`
--
ALTER TABLE `v6`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v7`
--
ALTER TABLE `v7`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v8`
--
ALTER TABLE `v8`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v9`
--
ALTER TABLE `v9`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `v10`
--
ALTER TABLE `v10`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `v1`
--
ALTER TABLE `v1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `v2`
--
ALTER TABLE `v2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `v5`
--
ALTER TABLE `v5`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `v6`
--
ALTER TABLE `v6`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `v7`
--
ALTER TABLE `v7`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `v8`
--
ALTER TABLE `v8`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `v9`
--
ALTER TABLE `v9`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `v10`
--
ALTER TABLE `v10`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
