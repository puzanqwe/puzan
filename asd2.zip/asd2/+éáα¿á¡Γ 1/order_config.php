<?php

    session_start();
    require_once 'config.php';

    $name = $_POST['name'];
    $phone = $_POST['phone'];

    mysqli_query($connect, "INSERT INTO `v1` (`id`, `name`, `phone`) VALUES (NULL, '$name', '$phone')");
    header('Location: ./index.php');

?>