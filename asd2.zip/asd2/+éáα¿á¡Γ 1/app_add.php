<?php

    session_start();
    require_once 'config.php';

    $nameApp = $_POST['nameApp'];
    $descriptionApp = $_POST['descriptionApp'];
    $idCategoryApp = $_POST['categoryApp'];
    
    $id_user = $_SESSION['user']['id'];

    $path = 'assets/img/uploads/imageApp/' . time() . $_FILES['imageApp']['name'];
    if (!move_uploaded_file($_FILES['imageApp']['tmp_name'], '../' . $path)) {
        echo 'Ошибка при загрузке изображения!';
    } else {
        mysqli_query($connect, "INSERT INTO `application`
        (`id`, `id_user`, `name`, `description`, `category`, `condition`, `image`) 
        VALUES (NULL,'$id_user','$nameApp','$descriptionApp','$idCategoryApp','Новая', '$path')");

        echo 'Заявка успешно добавлена!';
    };
?>
