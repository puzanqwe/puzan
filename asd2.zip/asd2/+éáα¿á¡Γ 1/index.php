<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<title>Droid</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<header class="header div_blue">
		<div class="container">
			<div class="header__inner">
				<div class="header__logo-block">
					<img class="header__logo" alt="logo" src="media/Images/logo.svg">
				</div>
				<nav class="header__menu">
					<a href="#" class="menu__item">О нас</a>
					<a href="#" class="menu__item">Цены</a>
					<a href="#" class="menu__item">Контакты</a>
					<a href="#" class="menu__item">Вакансии</a>
				</nav>
				<div class="header__contacts">
					<a href="tel:8(3822)94-06-06" class="contacts__item">Телефон</a>
					<a href="mailto:service@2droida.ru" class="contacts__item">E-mail</a>
					<a href="//send?phone=7903950645" class="contacts__item">Whatsapp</a>
					<a href="//vk.com/droid" class="contacts__item">VK</a>
					<a href="//instagram.com/droid" class="contacts__item">Instagram</a>
				</div>
				<div class="header__schedule-block">
					<span class="header__schedule">Ежедневно<br>10:00 — 20:00</span>
				</div>
				<a href="./order_list.php" class="menu__item">Список звонков</a>
			</div>
		</div>
	</header>
	<div class="call">
		<div class="container">
			<div class="call__inner inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Заказать звонок</h1>
				</div>
				<div class="inner__content">
					<form id="orders" class="inner__form" method="post" action="./order_config.php">
						<input name="name" type="text" class="form__input form__item" placeholder="Введите имя">
						<input name="phone" type="text" class="form__input form__item"  placeholder="Введите телефон">
						<input type="submit" class="form__submit form__item" value="Позвонить мне!">
					</form>
					<div class="inner__companies">
						<div class="inner__title-block">
							<h2 class="inner__title">Мы работаем с такими фирмами как</h2>
						</div>
						<div class="companies__content">
							<div class="company__item-block">
								<img class="company__item" alt="company" src="media/Content/firms/honor.jpg">
							</div>
							<div class="company__item-block">
								<img class="company__item" alt="company" src="media/Content/firms/huawei.jpg">
							</div>
							<div class="company__item-block">
								<img class="company__item" alt="company" src="media/Content/firms/meizu.jpg">
							</div>
							<div class="company__item-block">
								<img class="company__item" alt="company" src="media/Content/firms/mi.png">
							</div>
							<div class="company__item-block">
								<img class="company__item" alt="company" src="media/Content/firms/oneplus.jpg">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="advantages div_blue">
		<div class="container">
			<div class="advantages__inner inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Преимущества нашего сервиса</h1>
				</div>
				<div class="inner__content">
					<div class="advantages__item-block">
						<div class="advantages__title-block">
							<h2 class="advantages__title">Минимальные сроки ремонта</h2>
						</div>
						<div class="advantages__text-block">
							<p class="advantages__text">Благодаря большому опыту инженеров и наличию запасных частей на складе мы выполним ремонт быстро, качественно и недорого. До 80% заказов специалисты выполняют в день обращения.</p>
						</div>
					</div>
					<div class="advantages__item-block">
						<div class="advantages__title-block">
							<h2 class="advantages__title">Бесплатная диагностика</h2>
						</div>
						<div class="advantages__text-block">
							<p class="advantages__text">Диагностика в течении 5 минут. Инженеры на месте определят неполадки, стоимость ремонта и сколько времени это займет.</p>
						</div>
					</div>
					<div class="advantages__item-block">
						<div class="advantages__title-block">
							<h2 class="advantages__title">Ответственность за результат</h2>
						</div>
						<div class="advantages__text-block">
							<p class="advantages__text">Используем только качественные запасные части и строго соблюдаем технологию проведения ремонта. Предоставляем гарантию на выполненные работы и замененные комплектующие.</p>
						</div>
					</div>
					<div class="advantages__item-block">
						<div class="advantages__title-block">
							<h2 class="advantages__title">Информирование</h2>
						</div>
						<div class="advantages__text-block">
							<p class="advantages__text">Мы предоставляем нашим клиентам бесплатное sms-информирование о завершении ремонта. Специалисты нашего call-центра всегда готовы ответить на все Ваши вопросы.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="examples">
		<div class="container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Примеры неисправностей</h1>
				</div>
				<div class="inner__content">
					<div class="examples__item">
						<div class="examples__image-block">
							<img src="media/Content/brokes/1.png" class="examples__image" alt="phone">
						</div>
						<div class="examples__description">
							<div class="examples__title-block">
								<h2 class="examples__title">Замена дисплейного модуля</h2>
								<span class="examples__price">от 1000</span>
							</div>
							<div class="exaples__text-block">
								<p class="examples__text">Разбит дисплей, не работает сенсор, не показывает экран</p>
							</div>
						</div>
					</div>
					<div class="examples__item">
						<div class="examples__image-block">
							<img src="media/Content/brokes/2.png" class="examples__image" alt="phone">
						</div>
						<div class="examples__description">
							<div class="examples__title-block">
								<h2 class="examples__title">Замена аккумулятора</h2>
								<span class="examples__price">от 2000</span>
							</div>
							<div class="exaples__text-block">
								<p class="examples__text">Не держит заряд, выключается на холоде или вздулся аккумулятор. А так же, если попала влага или был сильный удар.</p>
							</div>
						</div>
					</div>
					<div class="examples__item">
						<div class="examples__image-block">
							<img src="media/Content/brokes/3.png" class="examples__image" alt="phone">
						</div>
						<div class="examples__description">
							<div class="examples__title-block">
								<h2 class="examples__title">Обновление программного обеспечения</h2>
								<span class="examples__price">от 300</span>
							</div>
							<div class="exaples__text-block">
								<p class="examples__text">Ошибки приложений Android, не работает Google Play, не открывается галерея, Не видит сеть, нет русского языка.</p>
							</div>
						</div>
					</div>
					<div class="examples__item">
						<div class="examples__image-block">
							<img src="media/Content/brokes/4.png" class="examples__image" alt="phone">
						</div>
						<div class="examples__description">
							<div class="examples__title-block">
								<h2 class="examples__title">Чистка от коррозии после попадания жидкости</h2>
								<span class="examples__price">от 1000</span>
							</div>
							<div class="exaples__text-block">
								<p class="examples__text">Залит телефон, внутри влага, утопили.</p>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</div>
	<div class="prices div_blue">
		<div class="prices__container container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Цены на наши услуги</h1>
				</div>
				<div class="inner__content">
					<div class="slider">
						<span class="slider__switch">&larr;</span>
						<div class="slider__content">
							<div class="slider__title-block">
								<h2 class="slider__title">Пересборка</h2>
							</div>
							<table border=1 frame="void" cellspacing="5" class="slider__table">
								<thead class="table__head">
									<tr class="table__row table__head-row">
										<th class="table__cell table__head-cell">Базовая цена</th>
										<th class="table__cell table__head-cell">Средняя сложность</th>
										<th class="table__cell table__head-cell">Сложный ремонт</th>
									</tr>
								</thead>
								<tbody class="table__body">
									<tr class="table__row">
										<td class="table__cell">200</td>
										<td class="table__cell">350</td>
										<td class="table__cell">500</td>
									</tr>
								</tbody>
							</table>
						</div>
						<span class="slider__switch">&rarr;</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="contacts">
		<div class="container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Связь с нами</h1>
				</div>
				<div class="inner__content">
					<div class="contacts__item-block">
						<a href="tel:8(3822)94-06-06" class="contacts__link">Телефон</a>
						<a href="mailto:service@2droida.ru" class="contacts__link">E-mail</a>
						<a href="//send?phone=7903950645" class="contacts__link">Whatsapp</a>
						<a href="//vk.com/droid" class="contacts__link">VKontakte</a>
						<a href="//instagram.com/droid" class="contacts__link">Instagram</a>
					</div>
				</div>	
			</div>
		</div>
	</div>
	<div class="feedback div_blue">
		<div class="container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Отзывы о нас</h1>
				</div>
				<div class="inner__content">
					<div class="slider">
						<span class="slider__switch">&larr;</span>
						<div class="feedback-slider__content">
							<div class="feedback-slider__title-block">
								<span class="slider__title">Георгий Леонидович</span>
								<span class="feedback__date">01.10.2019</span>
							</div>
							<div class="feedback__item">
								<h3 class="feedback__name">Замена АКБ Sony Xperia Z2</h3>
								<p class="feedback__text">24 сентября 2019 г обратился для замены АКБ в своем телефоне.НН Ленина 127. Мастер Сазанов А.Е. все адекватно обьяснил,показал и рассказал как будет проходить ремонт телефона.Назвал стоимость за батарею и замену АКБ. Назвал сроки.Все сделано качественно и в срок. Приятно с Вами работать. Спасибо.</p>
							</div>
						</div>
						<span class="slider__switch">&rarr;</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="fixes">
		<div class=" fixes__container container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Примеры наших работ</h1>
				</div>
				<div class="inner__content">
					<div class="slider">
						<span class="slider__switch">&larr;</span>
						<div class="slider__content">
							<div class="fixes__item">
								<img src="media/Content/fixes/8.jpg" class="fixes__image" alt="fix picture">
							</div>
						</div>
						<span class="slider__switch">&rarr;</span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<footer class="footer div_blue">
		<div class="container">
			<div class="inner">
				<div class="inner__title-block">
					<h1 class="inner__title">Краткая информация</h1>
				</div>
				<div class="inner__content footer__content">
					<div class="footer__item">
						<p class="footer__text">Сервисный центр DROID выполняет срочный, качественный и недорогой ремонт телефонов. Самые распространённые виды ремонта -это замена дисплея, антикоррозийная чистка при попадании влаги, замена аккумулятора и прошивка телефонов.</p>
					</div>
					<div class="footer__item">
						<p class="footer__text">Мы используем только качественные запасные части и строго соблюдаем технологию проведения ремонта. Мы предоставляем гарантию на выполненные работы и замененные комплектующие.</p>
					</div>
					<div class="footer__item">
						<ul class="footer__list">
							<li class="list__item">Наименование: ООО «С групп»</li>
							<li class="list__item">Юридический адрес: 634057, г. Новосибирск, ул. 79 Гвардейской дивизии, 7-179</li>
							<li class="list__item">ИНН: 7017417869</li>
							<li class="list__item">КПП: 762701001</li>
						</ul>
					</div>
					<div class="footer__item">
						<nav class="footer__menu">
							<a href="#" class="menu__item footer__menu-item">О нас</a>
							<a href="#" class="menu__item footer__menu-item">Цены</a>
							<a href="#" class="menu__item footer__menu-item">Контакты</a>
							<a href="#" class="menu__item footer__menu-item">Вакансии</a>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<button class="order-call">Заказать звонок!</button>
</body>
</html>